#include "header.h"

Output output;
Button button;
Motor motor;
Servo servo;

int main(void)
{
	Serial::init();
	
	output = Output(4); //oanv�nd
	button = Button(9);
	motor = Motor(7, 8, 5, TimerSelection::Timer2, 10, 1);
	servo = Servo(6, 2, 0, TimerSelection::Timer1, 2);
	
	//TCCR2B = (1<<CS20);
	
    button.enable_interrupt();
	
	// Sensor sensor(0, 2, 90, 1, 0.01, 0.1, 30, 150);
	/*for (double i = sensor.min(); i <= sensor.max(); i += 100)
	{
		sensor.set_input(i, sensor.max() - i);
		sensor.regulate();
		sensor.print();
	}
	*/
    while (true) 
    {
	
    }
	
	return 0;
}

